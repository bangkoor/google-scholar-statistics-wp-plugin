=== GSC Scholar Statistics ===
Contributors: Arif Kurnia Wijayanto
Tags: google scholar, citation, article
Requires at least: 3.5
Tested up to: 5.9.3
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Display author profile from Sinta (Science and Technology Index) - a Web-based research information system offering fast access, easy and comprehensive to measure the performance of researchers, institutions and journals in Indonesia.



== Description ==

This is the plugin for displaying Google Scholar Statistics or profile of specific user in WordPress site


** Features. **

* Simple and easy to use
* Displays Overal Score, 3 Years Score, National Rank, Affiliation Rank, Books, and IPR

== Installation ==

* Install & activate the plugin.

== How To Use ==

After installing the plugin, write down shortcode in page, post, or widget. 

Shortcode format: [gsc id="Your-GSC-ID" style="Choose-Style"]
Example: [gsc id="xfQppT0AAAAJ" style"blueSteelCols"]

Save! And that's it!

Available style: blueSteelCols and greenTable

== Screenshots ==


== Changelog ==

